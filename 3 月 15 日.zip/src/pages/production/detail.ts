export {
  renderProductionOrderDetailPage,
} from './core'
